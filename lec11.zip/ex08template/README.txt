The cabin in the woods image comes from

https://commons.wikimedia.org/w/index.php?title=Special:Search&limit=20&offset=20&profile=default&search=cabin+woods&searchToken=44ueoyp5524grga4kjb58ueyv#/media/File:A_Log_Cabin_in_the_Woods_-_panoramio.jpg

The code for this demo comes from

https://github.com/opencv/opencv/blob/master/samples/cpp/tutorial_code/Histograms_Matching/MatchTemplate_Demo.cpp

Ross Beveridge    February 11, 2018
